<div id="wp-quickotp-container" class="wp-quickotp-container-digikala">
    <div class="digikala-style-header">
        <h3>ورود | ثبت‌نام</h3>
    </div>
    <form id="wp-quickotp-form" action="" method="post">
        <p class="wp-quickotp-form-row">
            <label for="wp-quickotp-phone">شماره موبایل خود را وارد کنید</label>
            <input type="text" name="phone" id="wp-quickotp-phone" class="input" value="" placeholder="مثال: 09123456789">
        </p>
        <p class="wp-quickotp-form-row">
            <input type="submit" name="wp-quickotp-submit" id="wp-quickotp-submit" class="button button-primary" value="ورود">
        </p>
    </form>
    <div id="wp-quickotp-otp-container" style="display: none;">
        <form id="wp-quickotp-otp-form" action="" method="post">
             <p class="wp-quickotp-form-row">
                <label for="wp-quickotp-otp">کد تایید را وارد کنید</label>
                <input type="text" name="otp" id="wp-quickotp-otp" class="input" value="">
            </p>
            <p class="wp-quickotp-form-row">
                <input type="submit" name="wp-quickotp-otp-submit" id="wp-quickotp-otp-submit" class="button button-primary" value="تایید و ادامه">
            </p>
        </form>
        <div id="wp-quickotp-timer"></div>
    </div>
    <div id="wp-quickotp-message"></div>
</div>
