<div id="wp-quickotp-container" class="wp-quickotp-container-simple">
    <form id="wp-quickotp-form" action="" method="post">
        <p class="wp-quickotp-form-row">
            <label for="wp-quickotp-phone">شماره موبایل</label>
            <input type="text" name="phone" id="wp-quickotp-phone" class="input" value="" placeholder="09123456789">
        </p>
        <p class="wp-quickotp-form-row">
            <input type="submit" name="wp-quickotp-submit" id="wp-quickotp-submit" class="button button-primary" value="ارسال کد تایید">
        </p>
    </form>
    <div id="wp-quickotp-otp-container" style="display: none;">
        <form id="wp-quickotp-otp-form" action="" method="post">
            <p class="wp-quickotp-form-row">
                <label for="wp-quickotp-otp">کد تایید</label>
                <input type="text" name="otp" id="wp-quickotp-otp" class="input" value="">
            </p>
            <p class="wp-quickotp-form-row">
                <input type="submit" name="wp-quickotp-otp-submit" id="wp-quickotp-otp-submit" class="button button-primary" value="ورود">
            </p>
        </form>
        <div id="wp-quickotp-timer"></div>
    </div>
    <div id="wp-quickotp-message"></div>
</div>
