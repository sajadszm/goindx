(function( $ ) {
    'use strict';

    $(function() {
        var form = $( '#wp-quickotp-form' );
        var otpForm = $( '#wp-quickotp-otp-form' );
        var phoneInput = $( '#wp-quickotp-phone' );
        var otpInput = $( '#wp-quickotp-otp' );
        var messageContainer = $( '#wp-quickotp-message' );
        var timerContainer = $( '#wp-quickotp-timer' );

        form.on( 'submit', function( e ) {
            e.preventDefault();

            $.ajax({
                type: 'POST',
                url: wp_quickotp_ajax.ajax_url,
                data: {
                    action: 'send_otp',
                    phone: phoneInput.val(),
                    nonce: wp_quickotp_ajax.nonce
                },
                success: function( response ) {
                    if ( response.success ) {
                        form.hide();
                        otpForm.parent().show();
                        startTimer( 120 );
                    } else {
                        messageContainer.text( response.data.message );
                    }
                }
            });
        });

        otpForm.on( 'submit', function( e ) {
            e.preventDefault();

            $.ajax({
                type: 'POST',
                url: wp_quickotp_ajax.ajax_url,
                data: {
                    action: 'verify_otp',
                    phone: phoneInput.val(),
                    otp: otpInput.val(),
                    nonce: wp_quickotp_ajax.nonce
                },
                success: function( response ) {
                    if ( response.success ) {
                        window.location.reload();
                    } else {
                        messageContainer.text( response.data.message );
                    }
                }
            });
        });

        function startTimer( duration ) {
            var timer = duration, minutes, seconds;
            setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                timerContainer.text( minutes + ":" + seconds );

                if ( --timer < 0 ) {
                    timerContainer.text( 'کد تایید منقضی شد' );
                }
            }, 1000);
        }
    });
})( jQuery );
